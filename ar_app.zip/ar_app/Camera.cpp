#include "Camera.h"
#include "maths/matrix44.h"

Camera::Camera()
{
}


Camera::~Camera()
{
}

//Initialises all the values of the camera
void Camera::Initialise(gef::Vector4 camera_eye, gef::Vector4 camera_lookat, gef::Vector4 camera_up, float camera_fov, float near_plane, float far_plane)
{
	camera_eye_ = camera_eye;
	camera_lookat_ = camera_lookat;
	camera_up_ = camera_up;
	camera_fov_ = camera_fov;
	near_plane_ = near_plane;
	far_plane_ = far_plane;

}

//Sets up the matrices needed for the Renderer
void Camera::GetCameraMatrices(gef::Matrix44 & projection_matrix, gef::Matrix44 & view_matrix, gef::Platform* platform)
{
	projection_matrix = platform->PerspectiveProjectionFov(camera_fov_, (float)platform->width() / (float)platform->height(), near_plane_, far_plane_);
	view_matrix.LookAt(camera_eye_, camera_lookat_, camera_up_);
}
