#include "gef.h"
#include "maths/vector4.h"
#include "system/platform.h"
#pragma once
class Camera
{
public:
	Camera();
	~Camera();

	void Initialise(gef::Vector4 camera_eye, gef::Vector4 camera_lookat, gef::Vector4 camera_up, float camera_fov, float near_plane, float far_plane);

	void SetCameraEye(gef::Vector4 camera_eye) { camera_eye_ = camera_eye; }
	void SetCameraLookAt(gef::Vector4 camera_lookat) {camera_lookat_ = camera_lookat;}
	void SetCameraUp(gef::Vector4 camera_up) { camera_up_ = camera_up; }
	void SetCameraFov(float camera_fov) { camera_fov_ = camera_fov; }
	void SetCameraNearPlane(float near_plane) { near_plane_ = near_plane; }
	void SetCameraFarPlane(float far_plane) { far_plane_ = far_plane; }

	void GetCameraMatrices(gef::Matrix44 & projection_matrix, gef::Matrix44 & view_matrix, gef::Platform* platform);


private:
	gef::Vector4 camera_eye_;
	gef::Vector4 camera_lookat_;
	gef::Vector4 camera_up_;
	float camera_fov_;
	float near_plane_;
	float far_plane_;
	
};

