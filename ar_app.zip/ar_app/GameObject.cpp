#include "GameObject.h"
#include "graphics/mesh.h"

//constructor
GameObject::GameObject()
{
}

//deconstructor
GameObject::~GameObject()
{
	mesh_ = nullptr;
	transformation_matrix_ = nullptr;

}

//Method to initialise mesh values
//*Unspecified starting position (set to 0)
void GameObject::Initialise(const gef::Mesh* mesh)
{
	mesh_ = mesh;
	set_mesh(mesh_);
	SetPosition(gef::Vector4(0.0f, 0.0f, 0.0f));
	SetLocalPosition(gef::Vector4(0.0f, 0.0f, 0.01f));
}

//Method to initialise mesh values
//*Specify starting position
void GameObject::Initialise(const gef::Mesh* mesh, gef::Vector4 position)
{
	mesh_ = mesh;
	set_mesh(mesh_);
	SetPosition(position);
	SetLocalPosition(gef::Vector4(0.0f, 0.0f, 0.01f));
}

//sets the position of the mesh instance
void GameObject::SetPosition(gef::Vector4 position)
{
	position_ = position;
	CalculateTransformationMatrix();
}

//Sets the transform of the object using the marker transform
void GameObject::SetMarkerTransform(gef::Matrix44 transformMatrix)
{
	SetScale(gef::Vector4(0.05f, 0.05f, 0.05f));
	transformation_matrix_ = transformMatrix;
	SetLocalTransformMatrix(transformMatrix);
	transformation_matrix_ = transformation_matrix_ * scale_matrix_;
	transformation_matrix_.SetTranslation(transformMatrix.GetTranslation());
	transformation_matrix_  = transformation_matrix_* local_transform_matrix_;
	set_transform(transformation_matrix_);
}

//Method to set the local transformation matrix values using the marker transform
void GameObject::SetLocalTransformMatrix(gef::Matrix44 markerTransform)
{

	local_transform_matrix_.SetIdentity();

	//caclulate local position
	local_transform_matrix_.SetTranslation(local_position_);

	//calculate local scale
	local_scale_matrix.SetIdentity();
	
	//calculates local rotation
	local_rotation_matrix.SetIdentity();

	//calculate local transformation matrix
	local_transform_matrix_ = local_transform_matrix_ * local_scale_matrix * local_rotation_matrix;
}


//Sets the scale of the object
void GameObject::SetScale(gef::Vector4 scale)
{
	scale_ = scale;
	scale_matrix_.Scale(scale_);
}

//sets the aabb bounding sphere for the mesh
void GameObject::SetBoundingSphere(gef::Sphere sphere)
{
	//mesh_->set_bounding_sphere(sphere);
}

//Sets up the calculations for transformation matrix and sphere bounds
void GameObject::CalculateTransformationMatrix()
{
	gef::Matrix44 final_matrix;

	//sets the transformation matrix values
	transformation_matrix_.SetIdentity();

	gef::Sphere bounding_sphere(position_, 50.5f);

	SetBoundingSphere(bounding_sphere);

	scale_matrix_.Scale(scale_);

	transformation_matrix_.SetTranslation(position_);
	transformation_matrix_ = transformation_matrix_ * local_transform_matrix_;

	final_matrix = transformation_matrix_ * scale_matrix_;

	set_transform(final_matrix);
}

//increases speed of object
void GameObject::IncrementVelocity(gef::Vector4 velocity_increase)
{
	velocity_ += velocity_increase;
}

//Draws the mesh with the renderer3D construct
void GameObject::Draw(gef::Renderer3D* renderer)
{
	//if we have found a marker and rendering is enabled
	if (renderEnabled)
	{
		renderer->DrawMesh(*this);
	}
}

//Update physics and movement logic using gametime
void GameObject::Update(float GameTime)
{
	position_ += (velocity_ * GameTime);
	
	CalculateTransformationMatrix();
}
