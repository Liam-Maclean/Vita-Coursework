#pragma once
#include "m:\cmp404\ar_app\GameObject.h"
#include "primitive_builder.h"
#include <vector>
class GolfPlane
{
	enum GolfMode
	{
		circle,
		square,
		rectangle
	};
public:
	GolfPlane(PrimitiveBuilder* primbuilder);
	~GolfPlane();
	inline void SetGolfMode(GolfMode mode) { currentMode = mode; };
	void SetMarkerTransforms(gef::Matrix44 markerTransforms);
	void SetWalls(gef::Matrix44 markerTransform);
	void Update();
	void Draw(gef::Renderer3D* r3D);

private:
	std::vector<GameObject*> walls;
	GolfMode currentMode = GolfMode::square;
	bool firstScan = true;

	PrimitiveBuilder* prim_builder_;
};

