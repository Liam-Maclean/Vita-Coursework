#include "graphics/mesh_instance.h"
#include "graphics/scene.h"
#include "graphics/mesh.h"
#include "maths/sphere.h"
#include "graphics/renderer_3d.h"
#pragma once
class GameObject : gef::MeshInstance
{
public:
	GameObject();
	~GameObject();
	void Initialise(const gef::Mesh* mesh);
	void Initialise(const gef::Mesh* mesh, gef::Vector4 position);

	void SetPosition(gef::Vector4 position);
	void SetMarkerTransform(gef::Matrix44 matrix);
	void SetLocalTransformMatrix(gef::Matrix44 markerTransform);

	inline void SetLocalPosition(gef::Vector4 position) { local_position_.set_value(position.x(), position.y(), position.z()); }
	inline void SetLocalPositionX(float x) { position_.set_x(x); CalculateTransformationMatrix(); }
	inline void SetLocalPositionY(float y) { position_.set_y(y); CalculateTransformationMatrix(); }
	inline void SetLocalPositionZ(float z) { position_.set_z(z); CalculateTransformationMatrix(); }
	inline void SetPositionX(float x) { position_.set_x(x); CalculateTransformationMatrix(); }
	inline void SetPositionY(float y) { position_.set_y(y); CalculateTransformationMatrix(); }
	inline void SetPositionZ(float z) { position_.set_z(z); CalculateTransformationMatrix(); }
	inline void SetRenderEnabled(bool enabled){renderEnabled = enabled;}

	void SetScale(gef::Vector4 scale);
	void SetBoundingSphere(gef::Sphere sphere);
	void CalculateTransformationMatrix();
	inline const gef::Sphere GetBoundingSphere() { return mesh_->bounding_sphere(); }
	inline gef::MeshInstance GetThisInstance() { return *(this); }
	void IncrementVelocity(gef::Vector4 velocityIncrease);
	void Draw(gef::Renderer3D* renderer);

	void Update(float GameTime);

private:
	gef::Matrix44 local_scale_matrix;
	gef::Matrix44 local_rotation_matrix;
	gef::Matrix44 local_transform_matrix_;

	gef::Matrix44 rotation_matrix_;
	gef::Matrix44 scale_matrix_;
	gef::Matrix44 transformation_matrix_;

	const gef::Mesh* mesh_;

	gef::Vector4 local_position_;

	gef::Vector4 velocity_;
	gef::Vector4 scale_;
	gef::Vector4 position_;

	bool renderEnabled = true;
};

