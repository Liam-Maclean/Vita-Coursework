#include "GolfPlane.h"



GolfPlane::GolfPlane(PrimitiveBuilder* primBuilder)
{
	prim_builder_ = primBuilder;
}


GolfPlane::~GolfPlane()
{
}

//Sets the marker transforms of the walls
void GolfPlane::SetMarkerTransforms(gef::Matrix44 markerTransform)
{
	//if it's the first time the marker has been scanned
	if (firstScan)
	{
		//Set up the walls and set firstscan to false
		SetWalls(markerTransform);
		firstScan = false;
	}
	else
	{
		//Set the marker transform of all the walls to follow the marker transform of the card
		for (size_t i = 0; i < walls.size(); i++)
		{
			walls[i]->SetMarkerTransform(markerTransform);
		}
	}
}

//Sets the preset walls of the golf course
void GolfPlane::SetWalls(gef::Matrix44 markerTransform)
{
	//creates the geometry based on the current mode selected
	switch (currentMode)
	{
	case GolfMode::square:
		walls.push_back(new GameObject());
		walls.push_back(new GameObject());
		walls.push_back(new GameObject());
		walls.push_back(new GameObject());
		walls.push_back(new GameObject());

		walls[0]->Initialise(prim_builder_->CreateBoxMesh(gef::Vector4(0.1f, 1.5f, 0.5f)));
		walls[0]->SetLocalPosition(gef::Vector4(0.10f, 0.0f, 0.0f));
		walls[0]->SetMarkerTransform(markerTransform);

		walls[1]->Initialise(prim_builder_->CreateBoxMesh(gef::Vector4(0.1f, 1.5f, 0.5f)));
		walls[1]->SetLocalPosition(gef::Vector4(-0.10f, 0.0f, 0.0f));
		walls[1]->SetMarkerTransform(markerTransform);

		walls[2]->Initialise(prim_builder_->CreateBoxMesh(gef::Vector4(1.5f, 0.1f, 0.5f)));
		walls[2]->SetLocalPosition(gef::Vector4(0.0f, 0.075f, 0.0f));
		walls[2]->SetMarkerTransform(markerTransform);

		walls[3]->Initialise(prim_builder_->CreateBoxMesh(gef::Vector4(1.5f, 0.1f, 0.5f)));
		walls[3]->SetLocalPosition(gef::Vector4(0.0f, -0.075f, 0.0f));
		walls[3]->SetMarkerTransform(markerTransform);

		walls[4]->Initialise(prim_builder_->CreateBoxMesh(gef::Vector4(1.5f, 1.5f, 0.1f)));
		walls[4]->SetLocalPosition(gef::Vector4(0.0f, 0.0f, -0.05f));
		walls[4]->SetMarkerTransform(markerTransform);
		break;
	case GolfMode::circle:
		break;
	case GolfMode::rectangle:
		break;
	default:
		break;
	}
}

//Updates game logic if required
void GolfPlane::Update()
{

}

//Draws the walls
void GolfPlane::Draw(gef::Renderer3D* r3D)
{
	//Draw all the walls in the plane
	for (size_t i = 0; i < walls.size(); i++)
	{
		walls[i]->Draw(r3D);
	}
}
